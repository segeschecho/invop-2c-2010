#ifndef __include_H__
#define __include_H__

#include "C:\Program Files\CPLEX_Studio_AcademicResearch122\cplex\include\ilcplex\cplex.h"
#include <assert.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include <iostream>
#include <vector>
#include <list>
#include <algorithm>

#endif // __include_H__
